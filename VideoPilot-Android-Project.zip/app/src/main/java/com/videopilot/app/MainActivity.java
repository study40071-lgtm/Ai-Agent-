package com.videopilot.app;
import android.app.Activity; import android.os.Bundle; import android.graphics.Color; import android.view.ViewGroup; import android.widget.*;
public class MainActivity extends Activity {
 int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(22),dp(22),dp(22),dp(22)); l.setBackgroundColor(Color.rgb(247,248,250));
 TextView title=new TextView(this); title.setText("VideoPilot"); title.setTextSize(30); title.setTextColor(Color.rgb(24,42,70)); l.addView(title);
 TextView sub=new TextView(this); sub.setText("Create, review, then share your videos."); sub.setTextSize(16); l.addView(sub);
 add(l,"Create video","Video generation is not connected yet. This is the starter app.");
 add(l,"Review video","Video review tools will be added next.");
 add(l,"Prepare YouTube upload","Nothing uploads automatically. Review and approve first.");
 TextView note=new TextView(this); note.setText("Starter template only: video generation and YouTube integration are not implemented yet."); note.setPadding(0,dp(14),0,0); l.addView(note);
 ScrollView s=new ScrollView(this); s.addView(l); setContentView(s);}
 void add(LinearLayout l,String label,String msg){Button b=new Button(this); b.setText(label); b.setAllCaps(false); l.addView(b,new LinearLayout.LayoutParams(-1,-2)); b.setOnClickListener(v->Toast.makeText(this,msg,Toast.LENGTH_LONG).show());}
}
